package enums;

public enum tipoMetodoContacto {
    CHAT, EMAIL
}

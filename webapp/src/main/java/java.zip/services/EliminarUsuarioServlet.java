package services;

import dao.ManagerUsuarios;
import dao.ManagerUsuariosEliminados;
import classes.Usuario;
import classes.UsuarioEliminado;
import classes.UsuarioEliminadoImpl;
import enums.tipoMotivoEliminacion;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@WebServlet("/eliminarUsuario")
public class EliminarUsuarioServlet extends HttpServlet {

    // Método para manejar las solicitudes POST
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener el parámetro 'nombre' desde la solicitud (puede ser un parámetro GET
        // o POST)
        String correoElectronico = request.getParameter("correoElectronico");
        String motivoEliminacionStr = request.getParameter("motivoEliminacion"); // Obtener el motivo de eliminación
        tipoMotivoEliminacion motivoEliminacion = tipoMotivoEliminacion.valueOf(motivoEliminacionStr);

        // Verificar si se ha proporcionado un 'correo' válido
        if (correoElectronico == null || correoElectronico.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST); // 400
            response.getWriter()
                    .write("{\"status\": \"error\", \"message\": \"Correo del usuario no proporcionado.\"}");
            return;
        }

        //ManagerUsuarios managerUsuarios = new ManagerUsuarios();
        // Obtener la lista de usuarios desde ManagerUsuarios
        Usuario usuarioAEliminar = null;

        for (Usuario usuario : ManagerUsuarios.getUsuarios()) {
            // Comprobar si el correo electrónico coincide con el del usuario
            if (usuario.getCorreoElectronico().equalsIgnoreCase(correoElectronico)) {
                usuarioAEliminar = usuario; // Guardar el usuario a eliminar
                break;
            }
        }

        // Si no se encuentra el usuario, responder con un error
        if (usuarioAEliminar == null) {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND); // 404
            response.getWriter().write("{\"status\": \"error\", \"message\": \"Usuario no encontrado.\"}");
            return;
        }

        // Crear el objeto UsuarioEliminado
        UsuarioEliminado usuarioEliminado = new UsuarioEliminadoImpl(1000, "fecha", tipoMotivoEliminacion.INFRACCION);
        usuarioEliminado.setIdUsuario(usuarioAEliminar.getIdUsuario());
        usuarioEliminado.setFechaEliminacion(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        usuarioEliminado.setMotivoEliminacion(motivoEliminacion);

        // Agregar el usuario eliminado a ManagerUsuariosEliminados
        ManagerUsuariosEliminados managerUsuariosEliminados = new ManagerUsuariosEliminados();
        managerUsuariosEliminados.addUsuario(usuarioEliminado);

        // Llamar al ManagerUsuarios para eliminar al usuario con ese correo electrónico
        boolean eliminado = ManagerUsuarios.eliminarUsuario(correoElectronico);

        if (eliminado) {
            // Responder con un mensaje de éxito
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"status\": \"success\", \"message\": \"Usuario eliminado exitosamente.\"}");
        } else {
            // Si no se encuentra el usuario o ocurre un error en la eliminación
            response.setStatus(HttpServletResponse.SC_NOT_FOUND); // 404
            response.getWriter().write("{\"status\": \"error\", \"message\": \"Usuario no encontrado.\"}");
        }

    }
}

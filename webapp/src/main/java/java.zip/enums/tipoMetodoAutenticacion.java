package enums;

public enum tipoMetodoAutenticacion {
    CONTRASENYA, GOOGLE_OAUTH
}

package enums;

public enum tipoMotivoEliminacion {
    VOLUNTARIA, INFRACCION
}

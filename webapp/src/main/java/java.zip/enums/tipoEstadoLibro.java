package enums;

public enum tipoEstadoLibro {
    NUEVO, USADO
}

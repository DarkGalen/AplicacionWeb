package enums;

public enum tipoGenero {
    ACCION,
    AVENTURAS,
    TERROR,
    ROMANCE,
    FANTASIA,
    CIENCIA_FICCION,
    HISTORIA,
    OTROS
}
